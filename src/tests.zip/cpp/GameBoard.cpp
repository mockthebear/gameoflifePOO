#include <iostream>

using namespace std;

#include "../include/GameBoard.h"
#include "../include/Screen.h"





void GameBoard::update(GameOfLife& game) {



}
